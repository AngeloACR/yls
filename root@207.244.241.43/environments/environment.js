module.exports = {
  formularioPort: 2500,
  webPort: 3000,
  dbAddress: "mongodb://localhost:27017/yls",
};
